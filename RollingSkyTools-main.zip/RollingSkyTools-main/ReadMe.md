# Rolling Sky WebEditor

Rolling Sky WebEditor是由 **[ SQDL ](https://space.bilibili.com/3494378649684155?spm_id_from=333.1007.0.0)** 开发的饭制编辑器 \
本程序只对部分应用进行开放并且汉化,汉化人员 **[Glowi_Theme_](https://space.bilibili.com/3494378649684155?spm_id_from=333.1007.0.0)**


## 包含程序
> 地编编辑器\
> Geobuffer查询器\
> 地编加密器\
> 场景编辑器\
> 颜色对照表\